int main(void)
{
    long c;
    
    c = 6 / 7;
}