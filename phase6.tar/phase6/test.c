int main(void)
{
    int **a;
    int n;
    int i, j;

    a[0][0] = 1;
}