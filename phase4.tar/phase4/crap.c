int foo(void)
{
    int i, *p;

    i = (p < foo);
}
