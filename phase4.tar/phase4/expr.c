int printf();

int foo(int x, int *y)
{
    int a[10], i, *p;
    i = 0;
    i = (p < foo);		/* invalid operands to binary < */
}
