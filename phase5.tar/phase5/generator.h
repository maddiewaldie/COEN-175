#ifndef GENERATOR_H
#define GENERATOR_H

#include "Scope.h"
#include "Tree.h"
#include <iostream>

void generateGlobals(Scope *scope);

#endif //TYPE_H