open scope
x: (272,0,SCALAR)
x: (272,0,SCALAR)
a: (272,0,ARRAY)
a: (272,0,ARRAY)
x: (273,1,SCALAR)
g:(272,0,FUNCTION)
g:(272,1,FUNCTION)
f:(259,1,FUNCTION)
open scope
z: (272,0,SCALAR)
f: (259,1,FUNCTION)
close scope
f: (272,0,SCALAR)
h: (272,0,SCALAR)
h:(272,0,FUNCTION)
close scope
