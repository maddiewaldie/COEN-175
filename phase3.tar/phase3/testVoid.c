open scope
open scope
f: (285,0,FUNCTION)
close scope
x: (285,0,SCALAR)
open scope
y: (0,0,SCALAR)
g: (285,0,FUNCTION)
close scope
h:(285,1,SCALAR)
a: (285,0,ARRAY)
b: (285,1,ARRAY)
close scope
