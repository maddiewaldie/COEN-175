open scope
x: (272,0,SCALAR)
a: (272,0,SCALAR)
b: (272,1,ARRAY)
open scope
x: (272,0,SCALAR)
f: (272,0,SCALAR)
f: (272,1,FUNCTION)
y: (272,0,SCALAR)
add
eql
open scope
x: (272,0,SCALAR)
f: (272,0,SCALAR)
y: (272,0,SCALAR)
z: (272,0,SCALAR)
add
add
gtn
open scope
a: (272,0,SCALAR)
index
addr
close scope
close scope
close scope
close scope
